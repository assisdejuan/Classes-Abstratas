public class Pistoleiro extends Personagem {

    public Pistoleiro(String nome) {
        super(nome);
    }

    @Override
    public void atacar() {
        System.out.println("Pistoleiro " + getNome() + " está atacando com sua Desert Eagle");
    }

    public void atirar() {
        System.out.println("Pistoleiro " + getNome() + " está atirando!");
    }
}
