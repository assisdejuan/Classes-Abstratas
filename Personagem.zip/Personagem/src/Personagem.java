public class Personagem {
    private String nome;

    public Personagem(String nome) {
        this.nome = nome;
    }

    public void atacar() {
        System.out.println(nome + " está atacando!");
    }

    public void dizerNome() {
        System.out.println("Meu nome é " + nome);
    }

    public String getNome() {
        return nome;
    }
}



