public class Main {
    public static void main(String[] args) {
        Personagem personagem = new Personagem("Chandler");
        Pistoleiro pistoleiro = new Pistoleiro("Wolves");
        Sniper sniper = new Sniper("Tarantino");

        System.out.println("--- Personagem ---");
        personagem.dizerNome();
        personagem.atacar();

        System.out.println("\n--- Pistoleiro ---");
        pistoleiro.dizerNome();
        pistoleiro.atacar();
        pistoleiro.atirar();

        System.out.println("\n--- Sniper ---");
        sniper.dizerNome();
        sniper.mirar();
        sniper.atacar();
    }
}
