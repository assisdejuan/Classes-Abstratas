public class Sniper extends Pistoleiro {

    public Sniper(String nome) {
        super(nome);
    }

    public void mirar() {
        System.out.println("Sniper " + getNome() + " está mirando.");
    }

    @Override
    public void atacar() {
        System.out.println("Sniper " + getNome() + " está atacando com sua AW4");
    }
}
