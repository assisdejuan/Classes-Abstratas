public class Programador extends Funcionario {

    public Programador(String nome, double salario) {
        super(nome, salario);
    }

    @Override
    public void aumentaSalario() {
        double novoSalario = getSalario() * 1.20; // aumenta 20%
        setSalario(novoSalario);
    }
}
