import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Funcionario gerente = new Gerente("Carlos", 5000.00);
        Funcionario programador = new Programador("Ana", 4000.00);

        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Imprimir dados");
            System.out.println("2. Aumentar salário");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Imprimir dados de (1) Gerente ou (2) Programador? ");
                    int tipo1 = scanner.nextInt();
                    if (tipo1 == 1) {
                        gerente.imprimirDados();
                    } else if (tipo1 == 2) {
                        programador.imprimirDados();
                    } else {
                        System.out.println("Opção inválida.");
                    }
                    break;

                case 2:
                    System.out.print("Aumentar salário de (1) Gerente ou (2) Programador? ");
                    int tipo2 = scanner.nextInt();
                    if (tipo2 == 1) {
                        gerente.aumentaSalario();
                        System.out.println("Salário do gerente aumentado.");
                    } else if (tipo2 == 2) {
                        programador.aumentaSalario();
                        System.out.println("Salário do programador aumentado.");
                    } else {
                        System.out.println("Opção inválida.");
                    }
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }

        scanner.close();
    }
}