public class Gerente extends Funcionario {

    public Gerente(String nome, double salario) {
        super(nome, salario);
    }

    @Override
    public void aumentaSalario() {
        double novoSalario = getSalario() * 1.10; // aumenta 10%
        setSalario(novoSalario);
    }
}
